/*
 * configs.h
 *
 *  Created on: Nov 7, 2023
 *      Author: Marii
 */

#ifndef SERVICE_CONFIGS_H_
#define SERVICE_CONFIGS_H_
#include "functions.h"

#define value 50
#define TRUE 1
#define FALSE 0

#endif /* SERVICE_CONFIGS_H_ */
