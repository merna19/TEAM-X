/*
 * Check_IR.c
 *
 *  Created on: 6 Nov 2023
 *      Author: Ayaya
 */


#include "Check_IR.h"

void SERVICE_Check_IR()
{//
	//	// Initialize the IR sensor
	//	HAL_IR_Init();
	//	//Initialize the LED
	//	HAL_LED_INIT(LIVING_LED_PORT, LIVING_LED_PIN);
	// Read the IR sensor
	unsigned char value;
	value =HAL_IR_Read();

	if (value == DETECTED) {
		// Object is detected
		//Clear locked flag
		lockedFlag =0;
		// LED on
		HAL_LED_ON(LIVING_LED_PORT, LIVING_LED_PIN);
		//Set on flag
		onFlag =1;
		//Everything on
		SERVICE_EVERYTHING_ON();
	}
	else
	{
		// Object is not detected
	}
	_delay_ms(100); // Delay to prevent rapid readings
}
