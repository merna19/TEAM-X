/*
 * setOnFlag.h
 *
 *  Created on: 7 Nov 2023
 *      Author: Ayaya
 */

#ifndef SERVICE_SET_ON_FLAG_SETONFLAG_H_
#define SERVICE_SET_ON_FLAG_SETONFLAG_H_

#include "../EVERYTHING_ON/EverythingOn.h"

void SERVICE_SET_ON_FLAG();

#endif /* SERVICE_SET_ON_FLAG_SETONFLAG_H_ */
