/*
 * EverythingOn.c
 *
 *  Created on: 7 Nov 2023
 *      Author: Ayaya
 */


void SERVICE_EVERYTHING_ON()
{
	u8Data buffer[20];

	while(lockedFlag == 0)
	{
		SERVICE_TempControl();
		SERVICE_Curtain_Control();
		SERVICE_LEDS_Control();
		SERVICE_DisplayDateTime(&RTCData);
	}
}
